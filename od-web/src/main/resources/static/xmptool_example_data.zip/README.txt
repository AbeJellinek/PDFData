
                           /======================\
                           |                      |
                           | PDFData Example Data |
                           |    READ ME FIRST!    |
                           \______________________/

This is a set of example data for PDFData <https://pdf.abe.im/> to demonstrate
its reading and writing capabilities.

The included CSV file (`country_ranking.csv`) contains raw data from MIT's
Observatory of Economic Complexity <http://atlas.media.mit.edu/en/>, and the
PDF file (`country_ranking.pdf`) is a visual PDF containing embedded data in
PDFData's format. You can upload these files to the main reader/writer website
to experiment with their contents. All used data is licensed under the CC-BY-SA
license <http://creativecommons.org/licenses/by-sa/3.0/>, and you should use it
under the terms of that license.

Thanks for trying out PDFData!